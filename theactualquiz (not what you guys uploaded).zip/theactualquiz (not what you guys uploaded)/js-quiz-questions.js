/* [THE "DATABASE" - QUESTIONS, OPTIONS, ANSWERS] */
// An array that contains objects
// In the format of {q: QUESTION, o: OPTIONS, a: CORRECT ANSWER}
var questions = [
  {
    q : "1. Many celebrities, professional athletes, and entrepreneurs (people who can afford to live their desired lifestyles) have goals for their personal and professional achievements.  Why do these successful people set goals? ",
    o : [
      "Goal-setting allows them to measure progress toward accomplishments or lifestyle changes they desire.",
      "Setting goals provides them with direction.",
      "Goal-setting gives them an opportunity to show off to others.",
      "Both a and b."
    ],
    a : 3 // arrays start with 0, so it is 70 meters
  },
  {
    q : "2. Which of the following states the five important components of a good goal?",
    o : [
      "General, revised, active, safe, sound.",
      "Written, clear timeline, research-based, influenced by family, influenced by friends.",
      "Specific, measurable, achievable, realistic, time-driven.",
      "None of the above."
    ],
    a : 2
  },
  {
    q : "3. How can automating my finances save me time, protect my credit, and earn me extra money?",
    o : [
      "Organize all of your past accomplishments into an organized timeline.",
      "Daydream, think about and/or research the type of lifestyle you want to live, and write down ideas.",
      "Create a folder for school and extracurricular activities.",
      "Both b and c"
    ],
    a : 1
  },
  {
    q : "4. Which is the seventh planet from the sun?",
    o : [
      "Having bills paid automatically will reduce time spent on accounting; paying bills on time protects credit; and setting up direct deposit from your employer means you will earn maximum interest each month.",
      "Automating your finances cannot protect your credit or help you earn money.",
      "Automating your finances organizes all your accounts in one place that can easily be reviewed and updated online.",
      "Both a and c."
    ],
    a : 3
  },
  {
    q : "5. Choose the answer that best describes how to automate your finances.",
    o : [
      "Keep track of all the bills you pay on a spreadsheet, have a written budget, and set up an account with a bank or credit union.",
      "Have your employer direct deposit your paycheck, set up automatic bill-pay, set up automatic transfers to your savings account, and track all your finances on the mint.com website.",
      "Have all the companies you owe deduct their monthly payments directly from your checking account.",
      "None of the above"
    ],
    a : 1
  }
];