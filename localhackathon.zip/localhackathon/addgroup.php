<?php
require_once "app_config.php";
require_once "our_functions.php";


$error = "";
$cantcatchme = 0;


//Validate the group name
if (empty($_POST["group_name"])) {
    $error = "Name is required";
 } 
else {
    $name = test_input($_POST['group_name']);
    $cantcatchme += 1;
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }

if(empty($_POST["limit"])){
	$error .= "Limit is required<br>";
}
else{
	$limit = test_input($_POST['limit']);
	if(is_numeric($limit)){
		$cantcatchme += 1;
	}
}

if(empty($_POST["period"])){
	$error .= "Period is required<br>";
}
else{
	$period = test_input($_POST['period']);
	if(is_numeric($period)){
		$cantcatchme += 1;
	}
}


if(empty($_POST["goal"])){
	$error .= "Limit is required<br>";
}
else{
	$goal = test_input($_POST['goal']);
	if(is_numeric($goal)){
		$cantcatchme += 1;
	}
}


if($cantcatchme == 4){
	// prepare and bind

	$conn = mysqli_connect($servername,$username,$password,$database); 
	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}


	$stmt = $conn->prepare("INSERT INTO groups (group_name, max_users, date_created, period, goal) VALUES (?, ?, ?, ?, ?)");
	$stmt->bind_param("sisii", $a, $b, $c, $d, $e);

	// set parameters and execute
	$a = $name;
	$b = $limit;
	$c = date("Y/m/d");
	$d = $period;
	$e = $goal;
	$stmt->execute();

	/*/hello
		$date_create = date('y/m/d');
		$sql = "INSERT INTO groups (group_name, max_users, date_created, period, goal) VALUES ('$name', '$limit', '$date_create', '$period', '$goal')";

		if ($conn->query($sql) === TRUE) {
		    echo "New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();

	//hello*/


	$stmt->close();
	$conn->close();
}

else{
	echo $error;
}

?>