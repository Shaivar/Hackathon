<?php
$database = "unition";
$servername = "localhost";
$username = "root";
$password = "";
?>

