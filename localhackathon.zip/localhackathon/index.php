<!DOCTYPE HTML>
<html>
	<head>
		<title></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<script type="text/javascript" src="ourFunctions.js"></script>
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>


<body class="is-preload">

<!-- Wrapper -->
<div id="wrapper">

<!-- Header -->
<header id="header">
<div class="logo">
	<span class="icon fa-gem"></span>
</div>
<div class="content">
	<div class="inner">
		<h1>Stokvel</h1>
		<p>Save and grow with your peers</p>
	</div>
</div>
<nav>
	<ul>
		<li><a href="#intro">MY Groups</a></li>
		<li><a href="#work">Add New Group</a></li>
		<li><a href="#about">Invitations</a></li>
	</ul>
</nav>
</header>

<!-- Main -->
<div id="main">

<!-- Intro -->
	<article id="intro">
		<h2 class="major">Groups</h2>
		<span class="image main"><img src="images/pic01.jpg" alt="" /></span>
	<!-- Write an sql query that will then get a list of all the groups-->
	<ul>
		<?php
			require_once "app_config.php";
			$conn = mysqli_connect($servername,$username,$password,$database); 

			$sql = "SELECT group_name, id FROM groups";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
			    // output data of each row
			    while($row = $result->fetch_assoc()) {

			        echo "<li><a href='groups'>".$row['group_name']."</a></li>";
			    }
			} else {
			    echo "0 results";
			}
			$conn->close();

		?>
	</ul>
	<div id="my_groups">
	</div>
	</article>

<!-- Work -->
	<article id="work">
		<h2 class="major">Add A New Group</h2>
		<span class="image main"><img src="images/pic02.jpg" alt="" /></span>
		<div>
			<form name="Group" action="addgroup.php" method="post">
				<input type="text" name="group_name" placeholder="Enter group name" id="group_name">
				<input type="text" name="limit" min="5" max="15" placeholder="Enter number of users" id="number_of_users">
				<input type="text" name="period" placeholder="Enter period" id="saving_period">
				<input type="text" name="goal" placeholder="Enter goal amount" id="goal_amount">
				<div id="errors" style="background-color: red;color: white"></div>
				<input type="submit" value="Add new group">
			</form>
		</div>
	</article>

<!-- About -->
	<article id="about">
		<h2 class="major">INVITATIONS</h2>
		<span class="image main"><img src="images/pic03.jpg" alt="" /></span>
		<!-- php code to load invitations -->
		<p>Invitation1
			<div class='w3-section'>
				<button class='w3-button w3-green'>Accept</button> <button class='w3-button w3-red'>Decline</button>
				</div>
			</p>
	</article>

<!-- Scripts -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/browser.min.js"></script>
	<script src="assets/js/breakpoints.min.js"></script>
	<script src="assets/js/util.js"></script>
	<script src="assets/js/main.js"></script>
</body>
</html>
