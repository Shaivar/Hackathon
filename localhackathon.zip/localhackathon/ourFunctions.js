var group = {};

function addNewGroup(){
	var name,users,period,goal;
	name = document.forms['Group']['group_name'].value;
	users = document.forms['Group']['number_of_users'].value;
	period = document.forms['Group']['saving_period'].value;
	goal = document.forms['Group']['goal_amount'].value;

	group[0] = name;
	group[1] = users;
	group[2] = period;
	group[3] = goal;

	saveGroup();
	
}


function saveGroup(){

	if (typeof(Storage) !== "undefined") {
  	// Code for localStorage/sessionStorage.
  		localStorage.setItem("groups", group);
	} 
}

function loadGroup(){
	var link = localStorage.getItem("groups");
	document.getElementById('my_groups').innerHTML = "test";
}